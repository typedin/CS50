<?php

	print("pédé");
	
?>
